#!/usr/bin/env python3
"""
OCR 工具箱 - 百度AI Studio PaddleOCR服务封装
支持多种OCR模型：PP-OCRv5, PaddleOCR-VL, PaddleOCR-VL-1.5, PP-StructureV3

Author: plusseven

⚠️ 使用前请设置你的Token！跟AI说："帮我把OCR Token设置成我自己的"
获取Token: https://aistudio.baidu.com/paddleocr/task
"""

import os
import sys
import base64
import json
import time
import argparse
from pathlib import Path
from typing import Optional, Dict, Any, List

import requests


class OCRConfig:
    """OCR配置类"""

    # API Token - 请替换为你自己的Token
    # 跟AI说："帮我把OCR Token设置成我自己的" 即可自动配置
    TOKEN = "YOUR_TOKEN_HERE"  # ⚠️ 请替换成你自己的Token！

    # 模型配置
    MODELS = {
        "pp-ocrv5": {
            "name": "PP-OCRv5",
            "description": "基础OCR识别，支持中英日文",
            "job_url": "https://paddleocr.aistudio-app.com/api/v2/ocr/jobs",
            "result_key": "ocrResults",
            "output_text_key": "prunedResult"
        },
        "paddleocr-vl": {
            "name": "PaddleOCR-VL",
            "description": "视觉语言模型，支持布局解析",
            "job_url": "https://paddleocr.aistudio-app.com/api/v2/ocr/jobs",
            "result_key": "layoutParsingResults",
            "output_text_key": "markdown"
        },
        "paddleocr-vl-1.5": {
            "name": "PaddleOCR-VL-1.5",
            "description": "更高版本视觉语言模型",
            "job_url": "https://paddleocr.aistudio-app.com/api/v2/ocr/jobs",
            "result_key": "layoutParsingResults",
            "output_text_key": "markdown"
        },
        "pp-structurev3": {
            "name": "PP-StructureV3",
            "description": "结构化解析，支持表格识别",
            "job_url": "https://paddleocr.aistudio-app.com/api/v2/ocr/jobs",
            "result_key": "layoutParsingResults",
            "output_text_key": "markdown"
        }
    }


class OCRToolkit:
    """OCR工具箱主类"""

    def __init__(self, token: Optional[str] = None, model: str = "paddleocr-vl-1.5"):
        """
        初始化OCR工具箱

        Args:
            token: API访问令牌
            model: 使用的OCR模型
        """
        self.token = token or OCRConfig.TOKEN

        # 检查Token是否已设置
        if self.token == "YOUR_TOKEN_HERE":
            print("⚠️ 错误: 请先设置你的OCR Token！")
            print("获取Token: https://aistudio.baidu.com/paddleocr/task")
            print("然后跟AI说：'帮我把OCR Token设置成我自己的'")
            sys.exit(1)

        self.model = model

        if model not in OCRConfig.MODELS:
            raise ValueError(f"不支持的模型: {model}，请从以下模型中选择: {list(OCRConfig.MODELS.keys())}")

        self.model_config = OCRConfig.MODELS[model]
        self.job_url = self.model_config["job_url"]

    def _get_headers(self) -> Dict[str, str]:
        """获取请求头"""
        return {"Authorization": f"bearer {self.token}"}

    def _get_optional_payload(self, **kwargs) -> Dict[str, Any]:
        """
        构建可选参数

        Args:
            useDocOrientationClassify: 是否使用文档方向分类
            useDocUnwarping: 是否使用文档去扭曲
            useChartRecognition: 是否使用图表识别
            useTextlineOrientation: 是否使用文本行方向识别
        """
        return {
            "useDocOrientationClassify": kwargs.get("useDocOrientationClassify", False),
            "useDocUnwarping": kwargs.get("useDocUnwarping", False),
            "useChartRecognition": kwargs.get("useChartRecognition", False),
            "useTextlineOrientation": kwargs.get("useTextlineOrientation", False),
        }

    def _submit_job(self, file_path: str, optional_payload: Dict[str, Any]) -> str:
        """
        提交OCR任务

        Args:
            file_path: 文件路径或URL
            optional_payload: 可选参数

        Returns:
            任务ID
        """
        headers = self._get_headers()

        if file_path.startswith("http"):
            # URL模式
            headers["Content-Type"] = "application/json"
            payload = {
                "fileUrl": file_path,
                "model": self.model_config["name"],
                "optionalPayload": optional_payload
            }
            response = requests.post(self.job_url, json=payload, headers=headers)
        else:
            # 本地文件模式
            if not os.path.exists(file_path):
                raise FileNotFoundError(f"文件不存在: {file_path}")

            data = {
                "model": self.model_config["name"],
                "optionalPayload": json.dumps(optional_payload)
            }

            with open(file_path, "rb") as f:
                files = {"file": f}
                response = requests.post(self.job_url, headers=headers, data=data, files=files)

        if response.status_code != 200:
            raise RuntimeError(f"提交任务失败: {response.status_code} - {response.text}")

        return response.json()["data"]["jobId"]

    def _poll_job_result(self, job_id: str, poll_interval: int = 5) -> Optional[str]:
        """
        轮询任务结果

        Args:
            job_id: 任务ID
            poll_interval: 轮询间隔(秒)

        Returns:
            结果URL，如果任务失败返回None
        """
        headers = self._get_headers()

        while True:
            response = requests.get(f"{self.job_url}/{job_id}", headers=headers)

            if response.status_code != 200:
                raise RuntimeError(f"获取任务状态失败: {response.status_code}")

            data = response.json()["data"]
            state = data["state"]

            if state == "pending":
                print("任务状态: 等待中...")
            elif state == "running":
                try:
                    progress = data.get("extractProgress", {})
                    total = progress.get("totalPages", "?")
                    extracted = progress.get("extractedPages", 0)
                    print(f"任务状态: 处理中... ({extracted}/{total} 页)")
                except KeyError:
                    print("任务状态: 处理中...")
            elif state == "done":
                print("任务完成!")
                return data["resultUrl"]["jsonUrl"]
            elif state == "failed":
                error_msg = data.get("errorMsg", "未知错误")
                raise RuntimeError(f"任务失败: {error_msg}")

            time.sleep(poll_interval)

    def _fetch_and_parse_results(self, jsonl_url: str) -> List[Dict[str, Any]]:
        """
        获取并解析结果

        Args:
            jsonl_url: 结果文件URL

        Returns:
            解析后的结果列表
        """
        response = requests.get(jsonl_url)
        response.raise_for_status()

        results = []
        lines = response.text.strip().split("\n")

        for line in lines:
            line = line.strip()
            if not line:
                continue
            result = json.loads(line)["result"]
            results.extend(result.get(self.model_config["result_key"], []))

        return results

    def _extract_text(self, result: Dict[str, Any]) -> str:
        """
        从结果中提取文本

        Args:
            result: 单个结果对象

        Returns:
            提取的文本
        """
        output_key = self.model_config["output_text_key"]

        if output_key == "prunedResult":
            # 基础OCR结果
            return result.get("prunedResult", "")
        else:
            # Markdown结果
            markdown_data = result.get("markdown", {})
            return markdown_data.get("text", "")

    def process_file(
        self,
        file_path: str,
        output_dir: str = "output",
        save_images: bool = True,
        **options
    ) -> List[str]:
        """
        处理文件，执行OCR识别

        Args:
            file_path: 文件路径或URL
            output_dir: 输出目录
            save_images: 是否保存图片
            **options: 其他可选参数

        Returns:
            保存的文件路径列表
        """
        print(f"使用模型: {self.model_config['name']}")
        print(f"处理文件: {file_path}")

        # 提交任务
        optional_payload = self._get_optional_payload(**options)
        job_id = self._submit_job(file_path, optional_payload)
        print(f"任务ID: {job_id}")

        # 轮询结果
        jsonl_url = self._poll_job_result(job_id)

        if not jsonl_url:
            return []

        # 解析结果
        results = self._fetch_and_parse_results(jsonl_url)

        # 创建输出目录
        os.makedirs(output_dir, exist_ok=True)

        saved_files = []

        # 保存结果
        for i, result in enumerate(results):
            # 提取文本
            text = self._extract_text(result)

            # 保存文本
            if text:
                ext = ".md" if self.model_config["output_text_key"] == "markdown" else ".txt"
                text_file = os.path.join(output_dir, f"page_{i:03d}{ext}")

                with open(text_file, "w", encoding="utf-8") as f:
                    f.write(text)

                saved_files.append(text_file)
                print(f"文本已保存: {text_file}")

            # 保存图片
            if save_images:
                # 保存markdown中的图片
                if "markdown" in result and "images" in result["markdown"]:
                    for img_path, img_url in result["markdown"]["images"].items():
                        full_img_path = os.path.join(output_dir, img_path)
                        os.makedirs(os.path.dirname(full_img_path), exist_ok=True)

                        img_response = requests.get(img_url)
                        if img_response.status_code == 200:
                            with open(full_img_path, "wb") as f:
                                f.write(img_response.content)
                            saved_files.append(full_img_path)
                            print(f"图片已保存: {full_img_path}")

                # 保存输出图片
                if "outputImages" in result:
                    for img_name, img_url in result["outputImages"].items():
                        img_file = os.path.join(output_dir, f"{img_name}_{i}.jpg")

                        img_response = requests.get(img_url)
                        if img_response.status_code == 200:
                            with open(img_file, "wb") as f:
                                f.write(img_response.content)
                            saved_files.append(img_file)
                            print(f"输出图片已保存: {img_file}")

                # 保存OCR图片
                if "ocrImage" in result:
                    ocr_img_file = os.path.join(output_dir, f"ocr_result_{i}.jpg")
                    img_response = requests.get(result["ocrImage"])
                    if img_response.status_code == 200:
                        with open(ocr_img_file, "wb") as f:
                            f.write(img_response.content)
                        saved_files.append(ocr_img_file)
                        print(f"OCR图片已保存: {ocr_img_file}")

        return saved_files

    def get_text_only(self, file_path: str, **options) -> str:
        """
        仅获取识别的文本内容（不保存文件）

        Args:
            file_path: 文件路径或URL
            **options: 其他可选参数

        Returns:
            识别的完整文本
        """
        # 提交任务
        optional_payload = self._get_optional_payload(**options)
        job_id = self._submit_job(file_path, optional_payload)

        # 轮询结果
        jsonl_url = self._poll_job_result(job_id)

        if not jsonl_url:
            return ""

        # 解析结果
        results = self._fetch_and_parse_results(jsonl_url)

        # 合并所有文本
        all_text = []
        for result in results:
            text = self._extract_text(result)
            if text:
                all_text.append(text)

        return "\n\n".join(all_text)


def main():
    """命令行入口"""
    parser = argparse.ArgumentParser(description="OCR工具箱 - 百度AI Studio PaddleOCR服务封装")

    parser.add_argument("file", help="要处理的文件路径或URL")
    parser.add_argument("-m", "--model", default="paddleocr-vl-1.5",
                        choices=list(OCRConfig.MODELS.keys()),
                        help="OCR模型 (默认: paddleocr-vl-1.5)")
    parser.add_argument("-o", "--output", default="output",
                        help="输出目录 (默认: output)")
    parser.add_argument("-t", "--token", help="API访问令牌")
    parser.add_argument("--no-images", action="store_true",
                        help="不保存图片")
    parser.add_argument("--text-only", action="store_true",
                        help="仅输出文本到控制台，不保存文件")

    # 可选参数
    parser.add_argument("--orientation", action="store_true",
                        help="启用文档方向分类")
    parser.add_argument("--unwarping", action="store_true",
                        help="启用文档去扭曲")
    parser.add_argument("--chart", action="store_true",
                        help="启用图表识别")
    parser.add_argument("--textline", action="store_true",
                        help="启用文本行方向识别")

    args = parser.parse_args()

    # 创建OCR工具实例
    ocr = OCRToolkit(token=args.token, model=args.model)

    # 构建可选参数
    options = {
        "useDocOrientationClassify": args.orientation,
        "useDocUnwarping": args.unwarping,
        "useChartRecognition": args.chart,
        "useTextlineOrientation": args.textline,
    }

    try:
        if args.text_only:
            # 仅输出文本
            text = ocr.get_text_only(args.file, **options)
            print("\n" + "=" * 50)
            print("识别结果:")
            print("=" * 50)
            print(text)
        else:
            # 保存到文件
            saved_files = ocr.process_file(
                args.file,
                output_dir=args.output,
                save_images=not args.no_images,
                **options
            )

            print(f"\n处理完成! 共保存 {len(saved_files)} 个文件到 {args.output}/")

    except Exception as e:
        print(f"错误: {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
