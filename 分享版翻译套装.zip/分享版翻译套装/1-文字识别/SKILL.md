---
name: text-recognition
author: plusseven
description: 文字识别技能 - 从扫描版文档和图片中识别文字。支持OCR识别扫描版PDF/图片。使用场景：扫描版文档转文字、图片文字识别等。触发词：文字识别、OCR识别、识别文字、extract text、扫描版PDF、识别图片文字、图片转文字。
version: 1.0.0
---

# 文字识别 (Text Recognition)

从扫描版文档和图片中识别文字内容。

> **使用前必读**：请先在根目录 README.md 中了解如何设置Token！

## 工作流概览

```
扫描版/图片文件
    ↓
[OCR识别]
    ↓
识别的文本内容
    ↓
下一步: 2-格式转换
```

## 使用方法

```bash
# 基本用法
python ocr_toolkit.py /path/to/image.jpg

# 处理PDF
python ocr_toolkit.py /path/to/scanned.pdf -o ./output

# 使用不同模型
python ocr_toolkit.py image.jpg -m pp-ocrv5

# 处理网络图片
python ocr_toolkit.py https://example.com/document.jpg

# 仅输出文本到控制台
python ocr_toolkit.py image.jpg --text-only
```

## OCR模型选择

| 模型 | 说明 | 适用场景 |
|------|------|----------|
| pp-ocrv5 | 基础OCR，速度快 | 纯文字文档 |
| paddleocr-vl-1.5 | 视觉语言模型 | 复杂布局、表格（推荐） |
| pp-structurev3 | 结构化解析 | 表格密集文档 |

## 输出

OCR识别的文本内容保存到输出目录：
- 默认输出目录: `output/`
- 生成 `.md` 或 `.txt` 文件

## 依赖

```bash
pip install -r requirements.txt
```

## Token设置

⚠️ **重要**：使用前必须设置Token！

**超简单方法**：直接跟AI说

> "帮我把OCR Token设置成我自己的"

**获取Token地址**：
https://aistudio.baidu.com/paddleocr/task

---

**Author: plusseven**
