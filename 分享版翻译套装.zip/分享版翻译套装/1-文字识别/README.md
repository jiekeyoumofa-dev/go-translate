# 文字识别

从扫描版文档和图片中识别文字内容。

## 功能特点

- **OCR识别**: 支持图片、扫描版PDF的文字识别
- **多语言支持**: 支持中文、英文、日文识别
- **布局解析**: 支持复杂布局和表格识别

## 安装依赖

```bash
pip install -r requirements.txt
```

## 使用方法

```bash
# 基本用法
python ocr_toolkit.py /path/to/image.jpg

# 处理PDF
python ocr_toolkit.py /path/to/scanned.pdf -o ./output

# 使用不同模型
python ocr_toolkit.py image.jpg -m pp-ocrv5

# 处理网络图片
python ocr_toolkit.py https://example.com/document.jpg

# 仅输出文本到控制台
python ocr_toolkit.py image.jpg --text-only
```

## Token设置

⚠️ **使用前必须设置Token！**

**超简单方法**：跟AI说

> "帮我把OCR Token设置成我自己的"

AI会问你Token是什么，你输入后，AI会自动帮你配置好！

**获取Token地址**：
https://aistudio.baidu.com/paddleocr/task

---

**Author: plusseven**
