# 格式转换技能

将各种格式的文档转换为标准的Markdown格式。

## 支持的格式

- EPUB 电子书
- PDF 文档
- DOCX Word文档

## 快速开始

### EPUB转MD

```bash
# 1. 先解压EPUB
unzip book.epub -d book_folder/

# 2. 转换为Markdown
python epub_to_md.py book_folder/
```

输出：`md_en/` 文件夹，包含各章节的MD文件和合并的 `all_content.md`

### PDF转MD

```bash
python pdf_to_md.py document.pdf output/
```

### DOCX转MD

```bash
python docx_to_md.py document.docx output/
```

### 批量转换

```bash
python batch_convert.py
```

## 依赖安装

```bash
pip install beautifulsoup4 pymupdf python-docx
```

## 输出说明

转换后的文件保持原文档的结构：
- 标题层级
- 段落格式
- 列表
- 图片链接
- 代码块

---

**Author: plusseven**
