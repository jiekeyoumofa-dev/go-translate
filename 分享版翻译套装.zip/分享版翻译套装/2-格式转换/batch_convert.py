#!/usr/bin/env python3
"""
批量转换脚本 - 将所有支持格式的文件转换为MD
支持: EPUB, PDF, DOCX

Author: plusseven
"""
import os
import sys
from pathlib import Path
from typing import List

def get_files_to_convert(source_dir: str) -> tuple:
    """获取所有需要转换的文件"""
    source_path = Path(source_dir)

    pdf_files = sorted(source_path.glob("*.pdf"))
    epub_files = sorted(source_path.glob("*.epub"))
    docx_files = sorted(source_path.glob("*.docx"))

    return pdf_files, epub_files, docx_files

def convert_file(file_path: Path, output_dir: Path, script_dir: Path) -> bool:
    """转换单个文件"""
    try:
        ext = file_path.suffix.lower()
        file_output_dir = output_dir / file_path.stem
        file_output_dir.mkdir(parents=True, exist_ok=True)

        if ext == ".epub":
            # 先解压EPUB
            epub_dir = file_output_dir / "epub_extracted"
            os.system(f'unzip -q "{file_path}" -d "{epub_dir}"')

            # 转换为MD
            script = script_dir / "epub_to_md.py"
            result = os.system(f'cd "{epub_dir}" && python "{script}" .')

        elif ext == ".pdf":
            script = script_dir / "pdf_to_md.py"
            result = os.system(f'python "{script}" "{file_path}" "{file_output_dir}"')

        elif ext == ".docx":
            script = script_dir / "docx_to_md.py"
            result = os.system(f'python "{script}" "{file_path}" "{file_output_dir}"')

        return result == 0

    except Exception as e:
        print(f"✗ 处理失败 {file_path.name}: {e}")
        return False

def main():
    if len(sys.argv) < 2:
        print("用法: python batch_convert.py <源目录> [输出目录]")
        sys.exit(1)

    source_dir = sys.argv[1]
    output_dir = sys.argv[2] if len(sys.argv) > 2 else "output_md"
    script_dir = Path(__file__).parent

    source_path = Path(source_dir)
    if not source_path.exists():
        print(f"错误: 源目录不存在: {source_dir}")
        sys.exit(1)

    # 创建输出目录
    output_path = Path(output_dir)
    output_path.mkdir(parents=True, exist_ok=True)

    # 获取所有文件
    pdf_files, epub_files, docx_files = get_files_to_convert(source_dir)

    total_files = len(pdf_files) + len(epub_files) + len(docx_files)

    if total_files == 0:
        print(f"没有找到支持的文件 (PDF/EPUB/DOCX) 在 {source_dir}")
        return

    print(f"找到 {total_files} 个文件待转换")
    print(f"  PDF: {len(pdf_files)}")
    print(f"  EPUB: {len(epub_files)}")
    print(f"  DOCX: {len(docx_files)}")
    print()

    success_count = 0
    fail_count = 0

    # 转换所有文件
    all_files = list(pdf_files) + list(epub_files) + list(docx_files)

    for file_path in all_files:
        print(f"\n{'='*60}")
        print(f"处理: {file_path.name}")
        print(f"{'='*60}")

        if convert_file(file_path, output_path, script_dir):
            print(f"✓ 成功: {file_path.name}")
            success_count += 1
        else:
            print(f"✗ 失败: {file_path.name}")
            fail_count += 1

    # 汇总
    print(f"\n{'='*60}")
    print("转换完成!")
    print(f"  成功: {success_count}/{total_files}")
    print(f"  失败: {fail_count}/{total_files}")
    print(f"  输出目录: {output_dir}")
    print(f"{'='*60}")

if __name__ == "__main__":
    main()
