---
name: format-convert
author: plusseven
description: 格式转换技能 - 将各种格式的文档转换为标准的Markdown格式。支持EPUB、PDF、DOCX等格式。使用场景：电子书转MD、PDF转MD、Word转MD等。触发词：格式转换、convert format、转md、to markdown、epub转md、pdf转md、docx转md。
version: 1.0.0
---

# 格式转换 (Format Convert)

将各种格式的文档转换为标准的Markdown格式。

## 支持的格式

| 格式 | 输入 | 输出 |
|------|------|------|
| EPUB | .epub 文件或解压目录 | Markdown (.md) |
| PDF | .pdf 文件 | Markdown (.md) |
| DOCX | .docx 文件 | Markdown (.md) |

## 使用方法

```bash
# EPUB转MD
python epub_to_md.py <epub文件夹路径>

# PDF转MD
python pdf_to_md.py <pdf文件路径> <输出目录>

# DOCX转MD
python docx_to_md.py <docx文件路径> <输出目录>

# 批量转换
python batch_convert.py
```

## 脚本说明

| 脚本 | 用途 |
|------|------|
| `epub_to_md.py` | EPUB电子书转Markdown |
| `pdf_to_md.py` | PDF文档转Markdown |
| `docx_to_md.py` | Word文档转Markdown |
| `batch_convert.py` | 批量转换工具 |

## 输出

转换后的Markdown文件保存在指定输出目录：
- EPUB: `md_en/` 文件夹，包含分章节文件和合并文件 `all_content.md`
- PDF/DOCX: 输出目录中生成同名的 `.md` 文件

## 依赖

```bash
pip install beautifulsoup4 pymupdf python-docx
```

## 扩展性

这个模块支持长期更新和扩展。如需添加新格式，按照现有格式添加转换脚本即可。

---

**Author: plusseven**
