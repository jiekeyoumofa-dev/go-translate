#!/usr/bin/env python3
"""
EPUB to Markdown converter
Extracts HTML content from EPUB and converts to Markdown

Author: plusseven
"""
import os
import re
import html
from pathlib import Path
from bs4 import BeautifulSoup

def html_to_markdown(soup, base_dir):
    """Convert HTML content to Markdown"""
    # Remove script and style elements
    for script in soup(["script", "style"]):
        script.decompose()

    # Process images
    for img in soup.find_all('img'):
        src = img.get('src', '')
        if src and not src.startswith('http'):
            # Handle relative paths
            if src.startswith('..'):
                src = src.replace('../', '')
            img['src'] = f'epub_source/{src}'

    # Convert content
    md_lines = []

    for element in soup.descendants:
        if element.name == 'h1':
            text = element.get_text(strip=True)
            if text:
                md_lines.append(f"\n# {text}\n")
        elif element.name == 'h2':
            text = element.get_text(strip=True)
            if text:
                md_lines.append(f"\n## {text}\n")
        elif element.name == 'h3':
            text = element.get_text(strip=True)
            if text:
                md_lines.append(f"\n### {text}\n")
        elif element.name == 'p':
            text = element.get_text(strip=True)
            if text:
                md_lines.append(f"{text}\n")
        elif element.name == 'br':
            md_lines.append("\n")
        elif element.name == 'strong' or element.name == 'b':
            text = element.get_text(strip=True)
            if text:
                md_lines.append(f"**{text}**")
        elif element.name == 'em' or element.name == 'i':
            text = element.get_text(strip=True)
            if text:
                md_lines.append(f"*{text}*")
        elif element.name == 'a':
            href = element.get('href', '')
            text = element.get_text(strip=True)
            if href:
                md_lines.append(f"[{text}]({href})")
            else:
                md_lines.append(text)
        elif element.name == 'ul' or element.name == 'ol':
            md_lines.append("\n")
        elif element.name == 'li':
            text = element.get_text(strip=True)
            if text:
                parent = element.find_parent(['ul', 'ol'])
                if parent and parent.name == 'ul':
                    md_lines.append(f"- {text}")
                else:
                    md_lines.append(f"1. {text}")
        elif element.name == 'blockquote':
            text = element.get_text(strip=True)
            if text:
                md_lines.append(f"> {text}")
        elif element.name == 'hr':
            md_lines.append("\n---\n")
        elif element.name == 'code':
            text = element.get_text(strip=True)
            if text:
                md_lines.append(f"`{text}`")
        elif element.name == 'pre':
            text = element.get_text()
            md_lines.append(f"\n```\n{text}\n```\n")
        elif isinstance(element, str):
            text = element.strip()
            if text and element.parent.name not in ['p', 'h1', 'h2', 'h3', 'li', 'strong', 'em', 'a', 'code', 'title', 'script', 'style']:
                md_lines.append(text)

    # Clean up and join
    result = '\n'.join(md_lines)
    # Remove excessive blank lines
    result = re.sub(r'\n{3,}', '\n\n', result)
    return result.strip()

def convert_epub_to_md(epub_folder, output_folder):
    """Convert EPUB HTML files to Markdown"""
    epub_source = Path(epub_folder) / "epub_source"
    output_dir = Path(output_folder) / "md_en"
    output_dir.mkdir(parents=True, exist_ok=True)

    # Find all HTML files - also search in subdirectories
    html_files = sorted(epub_source.glob("*.html")) + sorted(epub_source.glob("*.xhtml"))
    # Also search in subdirectories (like OEBPS)
    for subdir in epub_source.iterdir():
        if subdir.is_dir():
            html_files.extend(sorted(subdir.glob("*.html")))
            html_files.extend(sorted(subdir.glob("*.xhtml")))

    # Remove duplicates and sort
    html_files = sorted(set(html_files))

    if not html_files:
        print(f"没有找到HTML文件在 {epub_source}")
        return

    all_content = []

    for html_file in html_files:
        print(f"处理: {html_file.name}")

        with open(html_file, 'r', encoding='utf-8') as f:
            content = f.read()

        soup = BeautifulSoup(content, 'html.parser')

        # Extract title if available
        title = soup.find('title')
        if title:
            title_text = title.get_text(strip=True)
            all_content.append(f"# {title_text}\n")

        # Convert body content
        body = soup.find('body')
        if body:
            md_content = html_to_markdown(body, epub_source)
            all_content.append(md_content)
        else:
            md_content = html_to_markdown(soup, epub_source)
            all_content.append(md_content)

    # Combine all content into one file
    combined_md = '\n\n'.join(all_content)

    # Also save individual chapters
    for i, html_file in enumerate(html_files):
        with open(html_file, 'r', encoding='utf-8') as f:
            content = f.read()

        soup = BeautifulSoup(content, 'html.parser')

        # Extract title
        title = soup.find('title')
        if title:
            title_text = title.get_text(strip=True)
            # Clean title for filename
            safe_title = re.sub(r'[^\w\s-]', '', title_text)[:50]
            filename = f"{i+1:02d}_{safe_title}.md"
        else:
            filename = f"{i+1:02d}_chapter.md"

        body = soup.find('body')
        if body:
            md_content = html_to_markdown(body, epub_source)
        else:
            md_content = html_to_markdown(soup, epub_source)

        output_file = output_dir / filename
        with open(output_file, 'w', encoding='utf-8') as f:
            f.write(md_content)

        print(f"保存: {output_file.name} ({len(md_content)} 字符)")

    # Save combined file
    combined_file = output_dir / "all_content.md"
    with open(combined_file, 'w', encoding='utf-8') as f:
        f.write(combined_md)

    print(f"\n完成! 转换了 {len(html_files)} 个HTML文件")
    print(f"输出文件夹: {output_dir}")
    print(f"合并文件: {combined_file}")

if __name__ == "__main__":
    import sys
    if len(sys.argv) > 1:
        convert_epub_to_md(sys.argv[1], sys.argv[1])
    else:
        print("用法: python epub_to_md.py <folder_path>")
