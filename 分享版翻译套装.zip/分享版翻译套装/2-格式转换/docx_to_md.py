#!/usr/bin/env python3
"""
DOCX转Markdown工具

Author: plusseven
"""
import sys
from pathlib import Path
from docx import Document

def docx_to_markdown(docx_path, output_dir):
    """将DOCX文件转换为Markdown格式"""
    docx_name = Path(docx_path).stem
    output_file = Path(output_dir) / f"{docx_name}.md"

    print(f"正在处理: {docx_path}")

    try:
        doc = Document(docx_path)
        markdown_content = []

        markdown_content.append(f"# {docx_name}\n\n")
        markdown_content.append(f"来源: {Path(docx_path).name}\n\n")
        markdown_content.append("---\n\n")

        for para in doc.paragraphs:
            text = para.text.strip()
            if text:
                # 根据样式判断是否为标题
                if para.style.name.startswith('Heading'):
                    level = para.style.name[-1]
                    if level.isdigit():
                        markdown_content.append(f"{'#' * int(level)} {text}\n\n")
                    else:
                        markdown_content.append(f"{text}\n\n")
                else:
                    markdown_content.append(f"{text}\n\n")

        # 保存为Markdown文件
        with open(output_file, 'w', encoding='utf-8') as f:
            f.write(''.join(markdown_content))

        print(f"✓ 完成: {output_file}")
        return True

    except Exception as e:
        print(f"✗ 错误: {e}")
        return False

if __name__ == "__main__":
    if len(sys.argv) < 3:
        print("用法: python docx_to_md.py <DOCX文件> <输出目录>")
        sys.exit(1)

    docx_to_markdown(sys.argv[1], sys.argv[2])
