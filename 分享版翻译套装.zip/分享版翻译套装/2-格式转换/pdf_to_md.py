#!/usr/bin/env python3
"""
PDF转Markdown工具
提取PDF文本内容并保存为Markdown格式

Author: plusseven
"""
import os
import sys
import pymupdf  # PyMuPDF
from pathlib import Path

def pdf_to_markdown(pdf_path, output_dir):
    """将PDF文件转换为Markdown格式"""
    pdf_name = Path(pdf_path).stem
    output_file = Path(output_dir) / f"{pdf_name}.md"

    print(f"正在处理: {pdf_path}")

    try:
        doc = pymupdf.open(pdf_path)
        markdown_content = []

        markdown_content.append(f"# {pdf_name}\n\n")
        markdown_content.append(f"来源: {Path(pdf_path).name}\n")
        markdown_content.append(f"总页数: {len(doc)}\n\n")
        markdown_content.append("---\n\n")

        for page_num in range(len(doc)):
            page = doc[page_num]
            text = page.get_text()

            if text.strip():
                markdown_content.append(f"## 第 {page_num + 1} 页\n\n")
                markdown_content.append(text)
                markdown_content.append("\n\n")

            if (page_num + 1) % 10 == 0:
                print(f"  已处理 {page_num + 1}/{len(doc)} 页")

        doc.close()

        # 保存为Markdown文件
        with open(output_file, 'w', encoding='utf-8') as f:
            f.write(''.join(markdown_content))

        print(f"✓ 完成: {output_file}")
        return True

    except Exception as e:
        print(f"✗ 错误: {e}")
        return False


def main():
    if len(sys.argv) < 3:
        print("用法: python pdf_to_md.py <PDF文件或目录> <输出目录>")
        sys.exit(1)

    input_path = sys.argv[1]
    output_dir = sys.argv[2]

    # 创建输出目录
    Path(output_dir).mkdir(parents=True, exist_ok=True)

    # 处理单个文件或目录
    if os.path.isfile(input_path):
        pdf_to_markdown(input_path, output_dir)
    elif os.path.isdir(input_path):
        pdf_files = list(Path(input_path).glob("*.pdf"))
        print(f"找到 {len(pdf_files)} 个PDF文件\n")

        for pdf_file in pdf_files:
            pdf_to_markdown(str(pdf_file), output_dir)
            print()


if __name__ == "__main__":
    main()
